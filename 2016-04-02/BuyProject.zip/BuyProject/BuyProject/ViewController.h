//
//  ViewController.h
//  BuyProject
//
//  Created by ligang on 16/4/2.
//  Copyright © 2016年 ligang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

