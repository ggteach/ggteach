//
//  ViewController.m
//  BuyProject
//
//  Created by ligang on 16/4/2.
//  Copyright © 2016年 ligang. All rights reserved.
//

#import "ViewController.h"
#import <GPUImage/GPUImage.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.view.backgroundColor = [UIColor purpleColor];
    
    //创建背景图片
    UIImage *image = [UIImage imageNamed:@"login_bg"];
    GPUImageGaussianBlurFilter *blurFilter = [[GPUImageGaussianBlurFilter alloc] init];
    blurFilter.blurRadiusInPixels = 5.0;
    UIImage *blurredImage = [blurFilter imageByFilteringImage:image];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:blurredImage];
    imageView.frame = self.view.bounds;
    [self.view addSubview:imageView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
